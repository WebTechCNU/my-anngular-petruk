/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CurrencyPipe } from './currency.pipe';

describe('Pipe: Currencye', () => {
  it('create an instance', () => {
    let pipe = new CurrencyPipe();
    expect(pipe).toBeTruthy();
  });
});
