import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { AsyncPipe, CurrencyPipe, NgFor } from '@angular/common';

@Component({
  selector: 'app-shipping',
  standalone: true,
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.css'],
  imports: [
    NgFor,
    CurrencyPipe,
    AsyncPipe,
  ],
})
export class ShippingComponent implements OnInit {
  shippingCost: any;
  constructor(private cartServise: CartService) { }

  ngOnInit() {
    this.shippingCost = this.cartServise.getShippingPrice();
  }

}
