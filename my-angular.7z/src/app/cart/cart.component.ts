import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { CurrencyPipe, NgFor } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-cart',
  standalone: true,
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
  imports: [CurrencyPipe, NgFor, RouterLink, FormsModule, ReactiveFormsModule],
})
export class CartComponent implements OnInit {

  items: any;
  checkoutForm: FormGroup;

  constructor(private cartService: CartService, private fromBuilder: FormBuilder) {
    this.checkoutForm = this.fromBuilder.group({
      name: "",
      address: ""
    });
  }

  ngOnInit() {
    this.items = this.cartService.getItems();
  }

  onSubmit(custumerData: any) {
    this.items = this.cartService.clearCart();
    this.checkoutForm.reset();

    console.warn("Your order has been submited", custumerData);
  }

}
