import { Component, Input, OnInit , Output, EventEmitter } from '@angular/core';
import { ProductListComponent } from '../product-list/product-list.component';
import { NgIf } from '@angular/common';

@Component({
    selector: 'app-product-alerts',
    standalone: true,
    imports: [NgIf],
    templateUrl: './product-alerts.component.html',
    styleUrl: './product-alerts.component.css'
})
export class ProductAlertsComponent implements OnInit{
    ngOnInit(): void {
        // throw new Error('Method not implemented.');
    }

    @Output() notify = new EventEmitter();

    @Input() product: any;
}
